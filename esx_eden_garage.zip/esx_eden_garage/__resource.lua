server_scripts {
	'@mysql-async/lib/MySQL.lua',
	'config.lua',
	'server.lua'
}
client_script {
	'config.lua',
	'client.lua'
}
