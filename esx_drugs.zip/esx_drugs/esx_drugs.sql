INSERT INTO `items` (name, label) VALUES
	('weed', 'Weed'),
	('weed_pooch', 'Pochon de weed'),
	('xanax', 'Xanax'),
	('xanax_pooch', 'Pochon de Xanax'),
	('coke', 'Coke'),
	('coke_pooch', 'Pochon de coke'),
	('meth', 'Meth'),
	('meth_pooch', 'Pochon de meth'),
	('heroin', 'Heroin'),
	('heroin_pooch', 'Pochon de Heroin'),
	('opium', 'Opium'),
	('opium_pooch', 'Pochon de opium')
;