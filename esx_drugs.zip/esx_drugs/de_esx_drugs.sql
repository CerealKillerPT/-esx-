INSERT INTO `items` (name, label) VALUES
	('weed', 'Grass'),
	('weed_pooch', 'Portion Grass'),
	('coke', 'Koks'),
	('coke_pooch', 'Portion Koks'),
	('meth', 'Meth'),
	('meth_pooch', 'Portion Meth'),
	('opium', 'Opium'),
	('opium_pooch', 'Portion Opium')
;